/**
 * Copyright (c) 2015 Digi International Inc.,
 * All rights not expressly granted are reserved.
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this file,
 * You can obtain one at http://mozilla.org/MPL/2.0/.
 *
 * Digi International Inc. 11001 Bren Road East, Minnetonka, MN 55343
 * =======================================================================
 */
package com.digi.xdmk.receivedigitaldata;

import com.digi.xbee.api.RemoteXBeeDevice;
import com.digi.xbee.api.XBeeDevice;
import com.digi.xbee.api.exceptions.XBeeException;
import com.digi.xbee.api.io.IOLine;
import com.digi.xbee.api.io.IOSample;
import com.digi.xbee.api.io.IOValue;
import com.digi.xbee.api.listeners.IIOSampleReceiveListener;

/**
 * XBee-PRO 900HP DigiMesh Kit Receive Digital Data Sample application.
 * 
 * <p>This sample Java application shows how to receive digital data from 
 * another XBee device on the same network using the XBee Java Library.</p>
 */
public class MainApp {
	
	/* Constants */
	
	// TODO Replace with the port where your receiver module is connected.
	private static final String PORT = "COM3";
	// TODO Replace with the baud rate of your receiver module.
	private static final int BAUD_RATE = 9600;
	// Digital line to monitor.
	private static final IOLine LINE = IOLine.DIO4_AD4;
	// Digital sample listener.
	private static DigitalSampleListener listener = new DigitalSampleListener();
	
	/**
	 * Application main method.
	 * 
	 * @param args Command line arguments.
	 */
	public static void main(String[] args) {
		System.out.println("+-----------------------------------------------+");
		System.out.println("|          Receive Digital Data Sample          |");
		System.out.println("+-----------------------------------------------+\n");
		
		XBeeDevice myDevice = new XBeeDevice(PORT, BAUD_RATE);
		
		try {
			myDevice.open();
			
			System.out.println("\nListening for IO samples... Press the user button of any remote device.\n");
			
			myDevice.addIOSampleListener(listener);
			
		} catch (XBeeException e) {
			e.printStackTrace();
			myDevice.close();
			System.exit(1);
		}
	}
	
	/**
	 * Class to manage the received IO data.
	 */
	private static class DigitalSampleListener implements IIOSampleReceiveListener {
		@Override
		public void ioSampleReceived(RemoteXBeeDevice remoteDevice, IOSample ioSample) {
			if (ioSample.hasDigitalValue(LINE)) {
				IOValue value = ioSample.getDigitalValue(LINE);
				System.out.println("Digital data from '" + remoteDevice.get64BitAddress() + 
						"': " + value + " (" + 
						(value == IOValue.HIGH ? "button released" : "button pressed") + ")");
			}
		}
	}
}