#Final program execute 3 tables at time

import os 
os.system('python position.py & python humidity.py & python temperature.py')	
