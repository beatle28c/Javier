#This program is deigned to get data from the Xbee pltaform
import datetime 
import numpy as np
import matplotlib.pyplot as plt
import time

t = datetime.datetime.now()
d = 0

while True:	
	time.sleep(1)
	with open('Prueba.txt', 'r') as f:
		data = f.readlines()
		for line in data:
			words = line.split()
			if (d==0):
				number = list(words[2])
				q=int(number[0]+number[1])*60+int(number[3]+number[4])
				d=1		
	num_lines = sum(1 for line in open('data.txt'))
	data = np.loadtxt('data.txt',float)
	plt.figure('DATA2')
	plt.axis([q, q+100 , 0, 2000])
	plt.xlabel('Time')
	plt.ylabel('Position')

	for i in range(num_lines):
		y = data [i,1]
		plt.scatter(q, y,color='green',s=100)
		plt.pause(0.001)
		q += 1
	time.sleep(30)
