#This program is deigned to get data from the Xbee pltaform
import datetime 
import numpy as np
import matplotlib.pyplot as plt
import time

t = datetime.datetime.now()
d = 0

while True:
	with open('Prueba.txt', 'r') as f:
		data = f.readlines()
		open("Xbee.txt", 'w').close()
		open("data.txt", 'w').close()
		for line in data:
			words = line.split()
			file = open("Xbee.txt", "a")
			file.write(words[0]+" "+words[1]+" "+words[2]+"\n")
			file.close()
			file = open("data.txt", "a")
			file.write(words[3]+" "+words[4]+" "+words[5]+"\n")
			file.close()
			if (d==0):
				number = list(words[2])
				q=int(number[0]+number[1])*60+int(number[3]+number[4])
				d=1
			
	num_lines = sum(1 for line in open('data.txt'))
	data = np.loadtxt('data.txt',float)
	print data
	plt.figure('DATA1')
	plt.axis([q, q+100 , 0, 2000])
	plt.xlabel('Time')
	plt.ylabel('Humidity')

	for i in range(num_lines):
		y = data [i,2]
		plt.scatter(q, y,color='blue',s=100)
		plt.pause(0.001)
		q += 1
	time.sleep(30)
